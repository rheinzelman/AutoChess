using UnityEngine;

public class King : ChessPiece
{

}
