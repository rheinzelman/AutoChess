using UnityEngine;

public class Knight : ChessPiece
{

}
