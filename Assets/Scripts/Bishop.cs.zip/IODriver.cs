using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

using System.Collections;
using System.Collections.Generic;
using System;

namespace IODriverNamespace
{

    public class IODriver : MonoBehaviour
    {

        private string initial_state;
        private string current_state;

        public IODriver(string initial, string current)
        {
            this.initial_state = initial;
            this.current_state = current;
        }

        public string GetUCIMove()
        {



            return null;

        }

        public string getInit()
        {
            return this.initial_state;
        }

    }
    }

}