using UnityEngine;

public class Bishop : ChessPiece
{

}
