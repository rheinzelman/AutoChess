using UnityEngine;

public class Pawn : ChessPiece
{
    
}
