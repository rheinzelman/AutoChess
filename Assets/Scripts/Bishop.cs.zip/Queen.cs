using UnityEngine;

public class Queen : ChessPiece
{

}
