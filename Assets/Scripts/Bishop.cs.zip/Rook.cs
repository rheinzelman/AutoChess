using UnityEngine;

public class Rook : ChessPiece
{

}
